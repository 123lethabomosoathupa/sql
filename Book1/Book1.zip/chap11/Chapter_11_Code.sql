-- ================================================================
-- CHAPTER 11: Working with Dates and Times
-- MAIN CODE
-- File paths set to: E:\school\SQL\Classwork\Book1\
-- ================================================================
-- NOTE: Download from https://www.nostarch.com/practicalSQL/
--   yellow_tripdata_2016_06_01.csv  → NYC taxi trip data


-- ================================================================
-- LISTING 11-1: Extracting components from a timestamp using date_part()
-- ================================================================

-- SELECT
--     date_part('year',    '2019-12-01 18:37:12 EST'::timestamptz) AS "year",
--     date_part('month',   '2019-12-01 18:37:12 EST'::timestamptz) AS "month",
--     date_part('day',     '2019-12-01 18:37:12 EST'::timestamptz) AS "day",
--     date_part('hour',    '2019-12-01 18:37:12 EST'::timestamptz) AS "hour",
--     date_part('minute',  '2019-12-01 18:37:12 EST'::timestamptz) AS "minute",
--     date_part('seconds', '2019-12-01 18:37:12 EST'::timestamptz) AS "seconds",
--     date_part('timezone_hour', '2019-12-01 18:37:12 EST'::timestamptz) AS "tz",
--     date_part('week',    '2019-12-01 18:37:12 EST'::timestamptz) AS "week",
--     date_part('quarter', '2019-12-01 18:37:12 EST'::timestamptz) AS "quarter",
--     date_part('epoch',   '2019-12-01 18:37:12 EST'::timestamptz) AS "epoch";


-- ================================================================
-- LISTING 11-2: Building datetime values from components
-- ================================================================

-- SELECT make_date(2018, 2, 22);
-- SELECT make_time(18, 4, 30.3);
-- SELECT make_timestamptz(2018, 2, 22, 18, 4, 30.3, 'Europe/Lisbon');


-- ================================================================
-- LISTING 11-3: current_timestamp vs clock_timestamp() during insert
-- ================================================================

-- CREATE TABLE current_time_example (
--     time_id bigserial,
--     current_timestamp_col timestamp with time zone,
--     clock_timestamp_col timestamp with time zone
-- );

-- INSERT INTO current_time_example (current_timestamp_col, clock_timestamp_col)
-- (SELECT current_timestamp,
--         clock_timestamp()
--  FROM generate_series(1,1000));

-- SELECT * FROM current_time_example;
-- Difference: current_timestamp is the SAME for all 1000 rows.
-- clock_timestamp() increments slightly as each row is inserted.


-- ================================================================
-- LISTING 11-4: Check your PostgreSQL server's time zone setting
-- ================================================================

-- SHOW timezone;


-- ================================================================
-- LISTING 11-5: List available time zone names and abbreviations
-- ================================================================

-- SELECT * FROM pg_timezone_abbrevs;
-- SELECT * FROM pg_timezone_names;

-- Filter to European time zones:
-- SELECT * FROM pg_timezone_names
-- WHERE name LIKE 'Europe%';


-- ================================================================
-- LISTING 11-6: Set time zone and observe how timestamps change
-- ================================================================

-- SET timezone TO 'US/Pacific';

-- CREATE TABLE time_zone_test (
--     test_date timestamp with time zone
-- );

-- INSERT INTO time_zone_test VALUES ('2020-01-01 4:00');

-- SELECT test_date FROM time_zone_test;
-- Result: 2020-01-01 04:00:00-08  (Pacific, UTC-8)

-- SET timezone TO 'US/Eastern';

-- SELECT test_date FROM time_zone_test;
-- Result: 2020-01-01 07:00:00-05  (Eastern, UTC-5 — 3 hrs ahead)

-- View as Korea Standard Time using AT TIME ZONE:
-- SELECT test_date AT TIME ZONE 'Asia/Seoul'
-- FROM time_zone_test;
-- Result: 2020-01-01 21:00:00  (Seoul is 13 hrs ahead of Pacific)


-- ================================================================
-- Simple date/time arithmetic (no table needed)
-- ================================================================

-- Subtract two dates (returns number of days):
-- SELECT '9/30/1929'::date - '9/27/1929'::date;
-- Result: 3

-- Add an interval to a date (returns a new timestamp):
-- SELECT '9/30/1929'::date + '5 years'::interval;
-- Result: 1934-09-30 00:00:00


-- ================================================================
-- LISTING 11-7: Create and import NYC yellow taxi trip data
-- ================================================================

-- SET timezone TO 'US/Eastern';

-- CREATE TABLE nyc_yellow_taxi_trips_2016_06_01 (
--     trip_id bigserial PRIMARY KEY,
--     vendor_id varchar(1) NOT NULL,
--     tpep_pickup_datetime timestamp with time zone NOT NULL,
--     tpep_dropoff_datetime timestamp with time zone NOT NULL,
--     passenger_count integer NOT NULL,
--     trip_distance numeric(8,2) NOT NULL,
--     pickup_longitude numeric(18,15) NOT NULL,
--     pickup_latitude numeric(18,15) NOT NULL,
--     rate_code_id varchar(2) NOT NULL,
--     store_and_fwd_flag varchar(1) NOT NULL,
--     dropoff_longitude numeric(18,15) NOT NULL,
--     dropoff_latitude numeric(18,15) NOT NULL,
--     payment_type varchar(1) NOT NULL,
--     fare_amount numeric(9,2) NOT NULL,
--     extra numeric(9,2) NOT NULL,
--     mta_tax numeric(5,2) NOT NULL,
--     tip_amount numeric(9,2) NOT NULL,
--     tolls_amount numeric(9,2) NOT NULL,
--     improvement_surcharge numeric(9,2) NOT NULL,
--     total_amount numeric(9,2) NOT NULL
-- );

-- COPY nyc_yellow_taxi_trips_2016_06_01 (
--     vendor_id,
--     tpep_pickup_datetime,
--     tpep_dropoff_datetime,
--     passenger_count,
--     trip_distance,
--     pickup_longitude,
--     pickup_latitude,
--     rate_code_id,
--     store_and_fwd_flag,
--     dropoff_longitude,
--     dropoff_latitude,
--     payment_type,
--     fare_amount,
--     extra,
--     mta_tax,
--     tip_amount,
--     tolls_amount,
--     improvement_surcharge,
--     total_amount
-- )
-- FROM 'E:\school\SQL\Classwork\Book1\yellow_tripdata_2016_06_01.csv'
-- WITH (FORMAT CSV, HEADER, DELIMITER ',');

-- CREATE INDEX tpep_pickup_idx
-- ON nyc_yellow_taxi_trips_2016_06_01 (tpep_pickup_datetime);

-- Verify row count (should be 368,774):
-- SELECT count(*) FROM nyc_yellow_taxi_trips_2016_06_01;


-- ================================================================
-- LISTING 11-8: Count taxi trips by hour of day
-- ================================================================

-- SELECT
--     date_part('hour', tpep_pickup_datetime) AS trip_hour,
--     count(*)
-- FROM nyc_yellow_taxi_trips_2016_06_01
-- GROUP BY trip_hour
-- ORDER BY trip_hour;


-- ================================================================
-- LISTING 11-9: Export hourly pickups to CSV for charting in Excel
-- ================================================================

-- COPY
-- (SELECT
--     date_part('hour', tpep_pickup_datetime) AS trip_hour,
--     count(*)
--  FROM nyc_yellow_taxi_trips_2016_06_01
--  GROUP BY trip_hour
--  ORDER BY trip_hour
-- )
-- TO 'E:\school\SQL\Classwork\Book1\hourly_pickups_2016_06_01.csv'
-- WITH (FORMAT CSV, HEADER, DELIMITER ',');


-- ================================================================
-- LISTING 11-10: Median trip duration by hour using percentile_cont()
-- ================================================================

-- SELECT
--     date_part('hour', tpep_pickup_datetime) AS trip_hour,
--     percentile_cont(.5)
--         WITHIN GROUP (ORDER BY
--             tpep_dropoff_datetime - tpep_pickup_datetime) AS median_trip
-- FROM nyc_yellow_taxi_trips_2016_06_01
-- GROUP BY trip_hour
-- ORDER BY trip_hour;


-- ================================================================
-- LISTING 11-11: Train trip data — Amtrak All American route
-- ================================================================

-- SET timezone TO 'US/Central';

-- CREATE TABLE train_rides (
--     trip_id bigserial PRIMARY KEY,
--     segment varchar(50) NOT NULL,
--     departure timestamp with time zone NOT NULL,
--     arrival timestamp with time zone NOT NULL
-- );

-- INSERT INTO train_rides (segment, departure, arrival)
-- VALUES
--     ('Chicago to New York',        '2017-11-13 21:30 CST', '2017-11-14 18:23 EST'),
--     ('New York to New Orleans',    '2017-11-15 14:15 EST', '2017-11-16 19:32 CST'),
--     ('New Orleans to Los Angeles', '2017-11-17 13:45 CST', '2017-11-18 9:00 PST'),
--     ('Los Angeles to San Francisco','2017-11-19 10:10 PST','2017-11-19 21:24 PST'),
--     ('San Francisco to Denver',    '2017-11-20 9:10 PST',  '2017-11-21 18:38 MST'),
--     ('Denver to Chicago',          '2017-11-22 19:10 MST', '2017-11-23 14:50 CST');

-- SELECT * FROM train_rides;


-- ================================================================
-- LISTING 11-12: Calculate duration of each train segment
-- ================================================================

-- SELECT segment,
--        to_char(departure, 'YYYY-MM-DD HH12:MI a.m. TZ') AS departure,
--        arrival - departure AS segment_time
-- FROM train_rides;


-- ================================================================
-- LISTING 11-13: Running total of trip time using sum() OVER
-- (note: output format is awkward — see Listing 11-14)
-- ================================================================

-- SELECT segment,
--        arrival - departure AS segment_time,
--        sum(arrival - departure) OVER (ORDER BY trip_id) AS cume_time
-- FROM train_rides;


-- ================================================================
-- LISTING 11-14: Better cumulative time using epoch seconds
-- ================================================================

-- SELECT segment,
--        arrival - departure AS segment_time,
--        sum(date_part('epoch', (arrival - departure)))
--            OVER (ORDER BY trip_id) * interval '1 second' AS cume_time
-- FROM train_rides;
-- Final cume_time: 133:47:00 (133 hours and 47 minutes total)
